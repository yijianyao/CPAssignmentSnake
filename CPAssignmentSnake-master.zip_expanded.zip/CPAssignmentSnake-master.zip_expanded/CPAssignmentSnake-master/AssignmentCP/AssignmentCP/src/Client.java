
public class Client {
	String name;
	
	public Client() {
		
	}
	
	public Client(String name) {
		this.name = name;
	}
}
