
public class Buffer {
	int size;
	

}
